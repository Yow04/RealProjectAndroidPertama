package com.example.submisi01pt2.ViewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.submisi01pt2.ListEventsItem
import com.example.submisi01pt2.Response
import com.example.submisi01pt2.api.APIclient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.http.Query
import retrofit2.Response as ApiResponse

class EventViewModel: ViewModel() {

    private val apiservice = APIclient().apiservice

    private val _upcomingEvents = MutableLiveData<List<ListEventsItem>>()
    val upcomingEvents: MutableLiveData<List<ListEventsItem>>
        get() = _upcomingEvents

    private val _finishedEvents = MutableLiveData<List<ListEventsItem>>()
    val finishedEvents: MutableLiveData<List<ListEventsItem>>
        get() = _finishedEvents

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: MutableLiveData<Boolean>
        get() = _isLoading

    fun fetchUpcomingEvents(){
        _isLoading.value = true
        viewModelScope.launch (Dispatchers.IO){
            val call = apiservice.getEvents("1")
            call.enqueue(object : Callback<Response>{
                override fun onResponse (call: Call<Response>, response: ApiResponse<Response>){
                    if (response.isSuccessful){
                        _upcomingEvents.postValue(response.body()?.listEvents?.filterNotNull())
                    }
                    _isLoading.postValue(false)
                }
                override fun onFailure (call: Call<Response>, t: Throwable){
                    _isLoading.postValue(false)
                }
            })
        }
    }

    fun fetchFinishedEvents(){
        _isLoading.value = true
        viewModelScope.launch (Dispatchers.IO){
            val call = apiservice.getEvents("0")
            call.enqueue(object : Callback<Response>{
                override fun onResponse (call: Call<Response>, response: ApiResponse<Response>){
                    if (response.isSuccessful){
                        _finishedEvents.postValue(response.body()?.listEvents?.filterNotNull())
                    }
                    _isLoading.postValue(false)
                }

                override fun onFailure (call: Call<Response>, t: Throwable){
                    _isLoading.postValue(false)
                }
            })
        }
    }

    fun searchFinishedEvents(query: String){
        _isLoading.value = true
        viewModelScope.launch (Dispatchers.IO){
            val call = apiservice.EventSearch(query, 0)
            call.enqueue(object :Callback<Response>{
                override fun onResponse (call: Call<Response>, response: ApiResponse<Response>){
                    if (response.isSuccessful){
                        _finishedEvents.postValue(response.body()?.listEvents?.filterNotNull())
                    }
                    _isLoading.postValue(false)
                }

                override fun onFailure (call: Call<Response>, t: Throwable){
                    _isLoading.postValue(false)
                }
            })
        }
    }

    fun searchUpcomingEvents(query: String){
        _isLoading.value = true
        viewModelScope.launch (Dispatchers.IO){
            val call = apiservice.EventSearch(query, 1)
            call.enqueue(object :Callback<Response>{
                override fun onResponse (call: Call<Response>, response: ApiResponse<Response>){
                    if (response.isSuccessful){
                        _finishedEvents.postValue(response.body()?.listEvents?.filterNotNull())
                    }
                    _isLoading.postValue(false)
                }

                override fun onFailure (call: Call<Response>, t: Throwable){
                    _isLoading.postValue(false)
                }
            })
        }
    }
}