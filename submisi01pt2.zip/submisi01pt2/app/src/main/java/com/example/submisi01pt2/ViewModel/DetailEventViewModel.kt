package com.example.submisi01pt2.ViewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.submisi01pt2.Detail
import com.example.submisi01pt2.ListEventsItem
import com.example.submisi01pt2.api.APIclient
import com.example.submisi01pt2.api.APIservice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailEventViewModel : ViewModel() {

    private val apiservice = APIclient().apiservice

    private var _eventDetail = MutableLiveData<ListEventsItem>()
    val eventDetail: LiveData<ListEventsItem> get() = _eventDetail

    private var _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get () = _isLoading

    fun getDetail(eventId: Int) {
        _isLoading.value = true
        viewModelScope.launch {
            val clien =apiservice.getEventsDetail(eventId)
            clien.enqueue(object : Callback<Detail> {
                override fun onResponse(
                    call: Call<Detail>,
                    response: Response<Detail>
                ) {
                   if (response.isSuccessful){
                       _eventDetail.value=response.body()?.listEvents
                       _isLoading.value = false
                   }
                }

                override fun onFailure(call: Call<Detail>, t: Throwable) {
                    _isLoading.value = false
                }
            })
        }
    }
}


