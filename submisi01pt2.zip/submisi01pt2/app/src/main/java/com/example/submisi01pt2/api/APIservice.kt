package com.example.submisi01pt2.api

import com.example.submisi01pt2.Detail
import com.example.submisi01pt2.Response
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface APIservice {
    @GET("events?")
    fun getEvents(@Query("active")active: String): Call<Response>
    @GET("events/{id}")
    fun getEventsDetail(@Path("id")eventId: Int): Call<Detail>
    @GET("events")
    fun EventSearch(@Query("q")query: String, @Query("active")active: Int): Call<Response>
}