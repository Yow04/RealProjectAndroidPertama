package com.example.submisi01pt2.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.submisi01pt2.DetailPage
import com.example.submisi01pt2.ListEventsItem
import com.example.submisi01pt2.databinding.EventItemBinding
import kotlinx.coroutines.withContext

class FinishedEventAdapter (
    private val context : Context,
    private val dataList: List<ListEventsItem>
): RecyclerView.Adapter<FinishedEventAdapter.MyViewHolder>() {
    inner class MyViewHolder(val binding: EventItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(event: ListEventsItem) {
            binding.eventName.text = event.name
            Glide.with(context)
                .load(event.mediaCover)
                .into(binding.eventImage)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = EventItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val event = dataList[position]
        holder.bind(event)
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailPage::class.java).apply {
                putExtra("eventId", event.id)
            }
            holder.itemView.context.startActivity(intent)
        }

    }
}
