package com.example.submisi01pt2

import com.google.gson.annotations.SerializedName

data class Detail(

	@field:SerializedName("event")
	val listEvents: ListEventsItem,

	@field:SerializedName("error")
	val error: Boolean? = null,

	@field:SerializedName("message")
	val message: String? = null
)
