package com.example.submisi01pt2.fragment

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submisi01pt2.Adapter.FinishedEventAdapter
import com.example.submisi01pt2.Adapter.UpcomingEventAdapter
import com.example.submisi01pt2.ViewModel.EventViewModel
import com.example.submisi01pt2.databinding.FragmentHomeBinding


class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    val viewModel: EventViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (requireActivity() as? AppCompatActivity)?.supportActionBar?.hide()

        binding.rvHorizontalUpcomingEvents.layoutManager = LinearLayoutManager(requireContext(),LinearLayoutManager.HORIZONTAL,false)
        binding.rvFinishedEvents.layoutManager= LinearLayoutManager(requireContext())

        viewModel.fetchUpcomingEvents().apply {

            viewModel.upcomingEvents.observe(viewLifecycleOwner, Observer {event ->
                if (event != null){
                    val limitEventUpcoming= event.take(5)
                    binding.rvHorizontalUpcomingEvents.adapter = UpcomingEventAdapter(requireContext(), limitEventUpcoming)
                } else {
                    Log.e("UpcomingEventsFragment", "Event is null")
                }
            })

        }

        viewModel.fetchFinishedEvents().apply {

            viewModel.finishedEvents.observe(viewLifecycleOwner, Observer {event ->
                if (event != null){
                    val limitEventFinished = event.take(5)
                    binding.rvFinishedEvents.adapter = FinishedEventAdapter(requireContext(), limitEventFinished)
                } else {
                    Log.e("FinishedEventsFragment", "Event is null")
                }
            })

        }

        viewModel.isLoading.observe(viewLifecycleOwner, Observer {isLoading ->
            binding.progressBar.visibility = if (isLoading == true) View.VISIBLE else View.GONE
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
