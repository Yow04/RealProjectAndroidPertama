package com.example.submisi01pt2

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.example.submisi01pt2.ViewModel.DetailEventViewModel
import com.example.submisi01pt2.databinding.ActivityDetailPageBinding

class DetailPage : AppCompatActivity() {

    private lateinit var binding: ActivityDetailPageBinding
    private val viewModel by viewModels<DetailEventViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val eventId = intent.getIntExtra("eventId", -1)
        if (eventId != -1) {
            viewModel.getDetail(eventId).apply {
                viewModel.eventDetail.observe(this@DetailPage) { event ->
                    Glide.with(this@DetailPage).load(event.mediaCover).into(binding.MediaCover)
                    binding.eventName.text = event.name
                    binding.ownerName.text = event.ownerName
                    binding.beginTime.text = event.beginTime
                    binding.quota.text = "${event.quota}"
                    val formatdescription = HtmlCompat.fromHtml(event.description ?: "",
                        HtmlCompat.FROM_HTML_MODE_LEGACY)
                    binding.desc.text = formatdescription
                    binding.desc.movementMethod = LinkMovementMethod.getInstance()
                    binding.btnlink.setOnClickListener {
                        val link = event.link
                        if (!link.isNullOrEmpty()) {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(event.link))
                            startActivity(intent)
                        } else {
                            Toast.makeText(this@DetailPage, "no valid link avail", Toast.LENGTH_SHORT).show()
                        }

                    }
                }
            }
        }
        viewModel.isLoading.observe(this) { isLoading ->
            if (isLoading){
                binding.progressBar.visibility = View.VISIBLE
            }else{
                binding.progressBar.visibility = View.GONE
            }
        }
    }
}

