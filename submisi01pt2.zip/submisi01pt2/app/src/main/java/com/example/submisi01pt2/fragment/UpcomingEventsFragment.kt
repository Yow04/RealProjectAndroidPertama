package com.example.submisi01pt2.fragment

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submisi01pt2.Adapter.UpcomingEventAdapter
import com.example.submisi01pt2.ViewModel.EventViewModel
import com.example.submisi01pt2.databinding.FragmentUpcomingEventsBinding

class UpcomingEventsFragment : Fragment() {

    private var _binding: FragmentUpcomingEventsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EventViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentUpcomingEventsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (requireActivity() as? AppCompatActivity)?.supportActionBar?.hide()

        viewModel.fetchUpcomingEvents().apply {

            viewModel.upcomingEvents.observe(viewLifecycleOwner, Observer {event ->
                if (event != null){
                    binding.rvUpcomingEvents.layoutManager = LinearLayoutManager(requireContext())
                    binding.rvUpcomingEvents.adapter = UpcomingEventAdapter(requireContext(), event)
                } else {
                    Log.e("UpcomingEventsFragment", "Event is null")
                }
            })

        }

        binding.searchview.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let {
                    viewModel.searchUpcomingEvents(it)
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {

                return false
            }
        })

        viewModel.isLoading.observe(viewLifecycleOwner, Observer {isLoading ->
            binding.progressBar.visibility = if (isLoading == true) View.VISIBLE else View.GONE
        })

    }

    override fun onDestroyView() {
        super.onDestroyView()
            _binding = null
    }
}